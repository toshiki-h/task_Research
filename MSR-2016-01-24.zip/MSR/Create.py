# -*- coding: utf-8 -*-
import subprocess
import os

result = subprocess.check_output('cat Qt_FilePath_2.csv  | cut -d"," -f1,2 | sort | uniq', shell=True)
result = result.replace("\r", "")
path_list = result.split("\n")
for info in path_list:
	r_id = info.split(",")[0]
	try:
		result = subprocess.check_output('egrep "^' + r_id + '," Qt_1.csv', shell=True)
	except subprocess.CalledProcessError:
		continue
	result = result.replace("\r", "")
	ans_list = result.split("\n")
	del ans_list[-1]
	for ans in ans_list:
		factor_list = ans.split(",")
		del factor_list[0]
		hoge = ",".join(factor_list)
		goal = info + "," +  hoge
		os.system("echo " + goal + " >> shironeco.csv")

"""
id_list = []
for n in path_list:
	id_list.append(n.split(",")[0])
id_list = list(set(id_list))
for r_id in id_list:
	result = subprocess.check_output('egrep "^' + r_id + '," Qt_1.csv')
	result = result.replace("\r", "")
	reviewer_list = result.split("\n")
"""