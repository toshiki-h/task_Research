import json, urllib2

f = open("C:\Users\kenichi-o\Desktop\MSR\os_rev_data\os_merged_detail_1.json","r")
root = json.loads(f.read())

print ("ID"+","+"Account_Id"+","+"Name"+","+"Review")
cnt = 0
names = {}
def replace_name(name):
	global cnt
	if not name in names:
		names[name] = str(cnt)
		cnt += 1
	return names[name]

for data in root:
	reviwe_ID = data["_number"]
	try:
		labels_all = data["labels"]["Code-Review"]["all"]
	except:
		continue
	review = set([])
	for i in data["messages"]:
		try:
			r_name = i["author"]["name"]
			review.add(r_name)
	#	review = set([i["author"]["name"] for i in data["messages"]])
		except:
			continue
	for i in labels_all:
		ID = i["_account_id"]
		try:
			name = i["name"]
		except:
			continue
		value = 0
		if name in review:
			value = 1
		try:
			print str(reviwe_ID) + "," + str(ID) + "," + str(name) + "," +  str(value)
		except:
			print str(reviwe_ID) + "," + str(ID) + "," + replace_name(name) + "," +  str(value)

f.close()