import csv

# def Longest_Common_Prefix(a, b):
# 	maxLen = 0
# 	for i in range (0,min(len(p_file_split),len(n_file_split))):
# 		if p_file_split[i] in n_file_split[i]:
# 			maxLen += 1
# 		else:
# 			break
# 	return maxLen

# def Longest_Common_Suffix(a, b):
# 	ctEquals = 0
# 	for k in range (max(len(p_file_split),len(n_file_split)),0,-1):
# 		try:
# 			if p_file_split[k-1] in n_file_split[k-1]:
# 				ctEquals += 1
# 			else:
# 				break
# 		except:
# 			continue
# 	return ctEquals

# def lcsubstring_length(a, b):
#     table = [[0] * (len(b) + 1) for _ in xrange(len(a) + 1)]
#     l = 0
#     for i, ca in enumerate(a, 1):
#         for j, cb in enumerate(b, 1):
#             if ca == cb:
#                 table[i][j] = table[i - 1][j - 1] + 1
#                 if table[i][j] > l:
#                     l = table[i][j]
#     return l

# def lcs_length(a, b):
#     table = [[0] * (len(b) + 1) for _ in xrange(len(a) + 1)]
#     for i, ca in enumerate(a, 1):
#         for j, cb in enumerate(b, 1):
#             table[i][j] = (
#                 table[i - 1][j - 1] + 1 if ca == cb else
#                 max(table[i][j - 1], table[i - 1][j]))
#     return table[-1][-1]

def path2List(fileString):
	return fileString.split("/")

def LCP(f1,f2):
	f1 = path2List(f1)
	f2 = path2List(f2)
	common_path = 0
	min_length = min(len(f1),len(f2))
	for i in range(min_length):
		if f1[i] == f2[i]:
			common_path += 1
		else:
			break
	return common_path

def LCSuff(f1,f2):
	f1 = path2List(f1)
	f2 = path2List(f2)
	common_path = 0
	r = range(min(len(f1),len(f2)))
	r.reverse()
	for i in r:
		if f1[i] == f2[i]:
			common_path += 1
		else:
			break
	return common_path

def LCSubstr(f1,f2):
	f1 = path2List(f1)
	f2 = path2List(f2)
	common_path = 0
	if len( set(f1) & set(f2)) > 0:
		mat = [[0 for x in range(len(f2)+1)] for x in range(len(f1)+1)]
		for i in range(len(f1)+1):
			for j in range(len(f2)+1):
				if i == 0 or j == 0:
					mat[i][j] = 0
				elif f1[i-1] == f2[j-1]:
					mat[i][j] = mat[i-1][j-1] + 1
					common_path = max(common_path,mat[i][j])
				else:
					mat[i][j] = 0
	return common_path

def LCSubseq(f1,f2):
	f1 = path2List(f1)
	f2 = path2List(f2)
	if len( set(f1) & set(f2)) > 0:
		L = [[0 for x in range(len(f2)+1)] for x in range(len(f1)+1)]
		for i in range(len(f1)+1):
			for j in range(len(f2)+1):
				if i == 0 or j == 0:
					L[i][j] = 0
				elif f1[i-1] == f2[j-1]:
					L[i][j] = L[i-1][j-1] + 1
				else:
					L[i][j] = max(L[i-1][j], L[i][j-1])
		common_path = L[len(f1)][len(f2)]
	else:
		common_path = 0
	return common_path    

def path_score(a,b):
	score = 0.0
 	score += LCP(a,b)
 	score += LCSuff(a,b)
 	score += LCSubstr(a,b)
 	score += LCSubseq(a,b)
	return score


f = open("C:\Users\kenichi-o\hoge\shironeco.csv","rb")
root = csv.reader(f)

counter_roop = 0
p_file_split = []
n_file_split = []
rid_data = {}

for data in root:
	if data[0] in rid_data:
		rid_data[data[0]].append(data[1:])
	else:
		rid_data[data[0]] = [data[1:]]
past_data = {}
for key in sorted(rid_data.keys()):
	lines = rid_data[key]
	for line in lines:
		score = 0.0
		if line[2] in past_data:
			p_data = past_data[line[2]]
			for d in p_data:
				score += path_score(line[0],d[0])
		print ",".join([key,line[2],str(score),line[3]])
	for line in lines:
		if line[2] in past_data:
			past_data[line[2]].append(line)
		else:
			past_data[line[2]] = [line]


# for i,data in enumerate(root):
# 	if i == 0:
# 		p_file_path = data[1]
# 		continue
# 		#p_file_path = data[1]
# 		#print p_file_path
# 	p_file_split = p_file_path.split("/")
# 	n_file_split = data[1].split("/")

# 	print p_file_split
# 	print n_file_split
# 	score = 0.0
# 	score += Longest_Common_Prefix(p_file_split,n_file_split)
# 	score += Longest_Common_Suffix(p_file_split,n_file_split)
# 	score += lcsubstring_length(p_file_split,n_file_split)
# 	score += lcs_length(p_file_split,n_file_split)
# 	print score
# 	p_file_path = data[1]

		#counter_roop += 1
		#continue
